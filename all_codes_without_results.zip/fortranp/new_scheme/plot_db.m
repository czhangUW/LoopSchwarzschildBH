% clc;clear;
% load('./result/find_db.dat')
% db=find_db(:,2);
% mval=find_db(:,3);
% mval1=unique(mval);
% %for i=1:length(mval1)
%  plot(log(mval),db,'o')
%  hold on
% %end
load('./result/lwstEofdb.dat')
db=lwstEofdb(:,2);
mval=lwstEofdb(:,1);
mval1=unique(mval);
plot(db,mval,'.')
hold on
clc;clear
gam=0.2375;agap=4*sqrt(3)*pi*gam;
load('./result/lwstrootm.dat')
deltab=lwstrootm(:,end);
m=0.5*(lwstrootm(:,1)+lwstrootm(:,4));
Am=2*m;
Am=4*pi*Am.^2;
plot(deltab,Am);
hold on
plot([deltab(1),deltab(end)],[agap,agap])





clc;clear;
load('./result/sample2.dat')
load('./result/eigenvalue2.dat')
sample=sample2;
eigenvalue=eigenvalue2;
m=eigenvalue(1,9);
ncut2=(eigenvalue(1,end)-1);

val=eigenvalue(:,1:4);
err=eigenvalue(:,5:8);
vec1=sample(1:ncut2+1,1:4)+1i*sample(1:ncut2+1,5:8);
vec2=sample(ncut2+2:2*ncut2+2,1:4)+1i*sample(ncut2+2:2*ncut2+2,5:8);
arg1=vec1(11,:);
arg1=vec1(11,:)./abs(arg1);
argm=repmat(arg1,ncut2+1,1);
vec1=vec1./argm;

eta=-ncut2/2:ncut2/2;

figure(2)
hold on
plot(eta,abs(vec2(:,4)),'r .')
plot(eta,abs(vec2(:,3)),'k .')
xlabel('$\eta$','Interpreter','latex','FontSize',20)
box('on')
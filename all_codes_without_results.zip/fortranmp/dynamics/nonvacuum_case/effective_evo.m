function [phi,eta,h]=effective_evo(m,etam,dy,phi0,onoff,nfoldm,nfoldp)
%% onoff is used to turn on/off pphi calculation onoff==0 turn off the calculation
gam=0.2375;
db=sqrt(4*sqrt(3)*pi*gam);
z=gam*db;
%%
pbm=etam*z;
pbm=pbm^2;
ym=gam*db*m*(-1-sqrt(pbm)/m);
yp=gam*db*m*(-1+sqrt(pbm)/m);
ymp=gam*db*m*(-1-sqrt((1+z^2)*pbm/(m^2)-z^2));
ymp=ymp/(1+z^2);
ypp=gam*db*m*(-1+sqrt((1+z^2)*pbm/(m^2)-z^2));
ypp=ypp/(1+z^2);
%%
if (onoff==0)
    phi=[];
    eta=[];
    return
else
   pphi=(pbm-m^2)*4*pi;
   pphi=sqrt(pphi);
   h=(pbm-m^2)*gam^2;
   y0=-m*z;
   y=[ymp:dy:y0,y0:dy:ypp,ypp];
   y=unique(y);
   t=sqrt((ypp-ym)/(ypp-ymp))*sqrt((y-ymp)./(y-ym));
   pb=-1/(z^2)*(y+m*z).^2+pbm;
   pb=sqrt(pb);
   
   eta=pb/(gam*db);
   theta=asin(t);
   phi=y;
   km=(yp-ym)*(ypp-ymp)/((ypp-ym)*(yp-ymp));
   parfor i=1:length(y)
      phi(i)=ellipticF(theta(i),km);
      midr=z*pphi/sqrt(1+z^2);
      midr=midr/(2*pi)
      phi(i)=midr/sqrt((ypp-ym)*(yp-ymp))*phi(i);
   end
   phi=phi-phi(y==y0);
   phi=phi+phi0;
   [phi,I]=sort(phi);
   eta=eta(I);
   phi=phi(:);
   eta=eta(:);
   phifoldm=repmat(phi,1,nfoldm);
   phifoldp=repmat(phi,1,nfoldp);
   etafoldm=repmat(eta,1,nfoldm);
   etafoldp=repmat(eta,1,nfoldp);
   etafoldp(:,1:2:end)=etafoldp(end:-1:1,1:2:end);
   etafoldm(:,end:-2:1)=etafoldm(end:-1:1,end:-2:1);
   phifoldp(:,1)=abs(phi(end:-1:1)-phi(end))+phi(end);
   phifoldm(:,end)=phi(1)-abs(phi(end:-1:1)-phi(1));
   for i=2:nfoldp
     phifoldp(:,i)=abs(phifoldp(end:-1:1,i-1)-phifoldp(end,i-1))+phifoldp(end,i-1);
   end
   for i=nfoldm-1:-1:1
       phifoldm(:,i)=phifoldm(1,i+1)-abs(phifoldm(end:-1:1,i+1)-phifoldm(1,i+1));
   end
   etafoldm=etafoldm(:);phifoldm=phifoldm(:);
   etafoldp=etafoldp(:);phifoldp=phifoldp(:);
   phi=[phifoldm;phi;phifoldp];
   eta=[etafoldm;eta;etafoldp];
   
end
end

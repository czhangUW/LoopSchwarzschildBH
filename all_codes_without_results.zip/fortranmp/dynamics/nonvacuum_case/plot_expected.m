clc; 
clear;
load('./result/expeta.dat')
load('./result/exph.dat')
load('./result/eigenvec_gau.dat')
load('./result/eigenval_gau.dat')
% Plot Gaussian package
vec=eigenvec_gau;
vec=vec(1:2:end,:)+1i*vec(2:2:end,:);
phi1=eigenval_gau(1:end-2);
ncut=eigenval_gau(end-1);
m0=eigenval_gau(end);
eta1=-ncut:ncut;
[xx,yy]=meshgrid(eta1,phi1);
f1=figure(1);
f1.Units='inches';
f1.Position=[0 2 9 27/4];
ax=axes(f1);
mesh(xx,yy,abs(vec))
view(ax,[60,85]);
ylabel('$\varphi$','Interpreter','latex','FontSize',25,'Position',...
    [2880.51,0.05,-0.0017])
xlabel('$|\eta|$','Interpreter','latex','FontSize',25,'Position',...
    [0,-5.85,-0.001])
ax.XLim=[-2500,2500];
ax.YTick=-5:5;
f1.PaperPosition=[0 0 9 27/4];
f1.PaperSize=[9 27/4];
print(f1,'-dpdf','-r300','./fig/gau_pack')

%% plot expection value
m=expeta(:,1);
m=unique(m);
m=m(:);
m=m';

phi=expeta(:,2);
phi=unique(phi);
phi=phi(:);
mm=repmat(m,length(phi),1);
phim=repmat(phi,1,length(m));
eta=ones(length(phi),length(m));
for i=1:length(m)
    ind=find(expeta(:,1)==m(i));
    eta(:,i)=expeta(ind,3);
end
indm=find(m==m0);
if indm~=0 
   indmax=find(eta(:,indm)==max(eta(:,indm)));
   x=phi(indmax-10:indmax+10);
   y=eta(indmax-10:indmax+10,indm);
   sp=spline(x,y);
   phi0=fnzeros(fnder(sp));
   eta0=fnval(sp,phi0);
   [phieff,etaeff,h]=effective_evo(m(indm),...
       0.5*(eta0(1)+eta0(2)),0.1,phi0(1),1,3,2);
   f2=figure(2);
   f2.Units='inches';
   f2.Position=[0,2,9,27/4];
   ax=axes(f2);
   plot(phi,eta(:,indm),'.','MarkerSize',12,'Color',[0.9,0.33,0.10],...
       'Parent',ax,'DisplayName','Quantum Dynamics')
   hold on
   plot(phieff,etaeff,'k -','LineWidth',1,'parent',ax,'DisplayName','Effective Dynamics')
   ax.YLim=[0,2700];
   ax.XLim=[-5.1,5.1];
   legend('show','FontSize',15,'Position',[0.6 0.8 0.27 0.083])
   xlabel(ax,'$\varphi$','Interpreter','latex','FontSize',20)
   ylabel(ax,'$|\eta|$','Interpreter','latex','FontSize',20)
   f2.PaperPosition=[0 0 9 27/4];
   f2.PaperSize=[9 27/4];
   print(f2,'-dpdf','-painters','evo_expeta')
else
    disp('There is no m equal to m0');
end
%%
f3=figure(3);
f3.Units='inches';
f3.Position=[0,0,9,12];
%%
ax2=axes(f3,'Position',[0.12,0.55,0.8,0.4]);
mesh(xx,yy,abs(vec),'Parent',ax2)
view(ax2,[60,85]);
ylabel('$\varphi$','Interpreter','latex','FontSize',20,'Position',...
    [2880.51,0.05,-0.0017])
xlabel('$\eta$','Interpreter','latex','FontSize',20,'Position',...
    [0.0,-5.85,-0.001])
zlabel(ax2,'$\mathcal P^{1/2}$','Interpreter','latex','FontSize',15,'Position',...
    [-2561.,-5.5,0.25])
ax2.XLim=[-2500,2500];
ax2.YTick=-5:5;
%%
ax1=axes(f3,'Position',[0.12,0.08,0.8,0.4]);
plot(phi,eta(:,indm),'.','MarkerSize',12,'Color',[0.9,0.33,0.10],...
       'Parent',ax1,'DisplayName','Quantum Dynamics')
hold on
plot(phieff,etaeff,'k -','LineWidth',1,'parent',ax1,'DisplayName','Effective Dynamics')
ax1.YLim=[0,2700];
ax1.XLim=[-5.1,5.1];
legend('show','FontSize',15,'Position',[0.64 0.42 0.20 0.043])
xlabel(ax1,'$\varphi$','Interpreter','latex','FontSize',20)
ylabel(ax1,'$|\eta|$','Interpreter','latex','FontSize',20)
f3.PaperPosition=[0,-0.2,9,12];
f3.PaperSize=[9,11.4];
print(f3,'-dpdf','-r600','./fig/dynmc_nonvcm')




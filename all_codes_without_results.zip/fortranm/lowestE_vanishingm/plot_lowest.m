clc;clear
load('./r_lowestE.dat')
result=r_lowestE;
m=result(:,1);
ritz=m;
err=m;
rm=m;
for i=1:length(m)
    rst1=result(i,2:5);
    rst2=result(i,6:end);
    [rst1,I]=sort(rst1);
    rst2=rst2(I);
    ind=find(rst1>=0);
    ritz(i)=rst1(ind(1));
    err(i)=rst2(ind(1));
end
f1=figure(1);
a1=axes(f1);
plt1=plot(m(1:10),ritz(1:10),'k.','MarkerSize',5,'Parent',a1);
xlabel('$m$','Interpreter','latex','FontSize',20)
ylabel('$\omega_o(m)$','Interpreter','latex','Fontsize',20)
f1.Units='inches';
f1.Position=[0,0,12,9];
f1.PaperPosition=[0 0 12 9];
f1.PaperSize=[12,9];
print('-dpdf','-Painters','lowestE')
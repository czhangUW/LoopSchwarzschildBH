clc;clear
load('../fortranm/discrete_m/result/rootm2.dat')
m1=rootm2(:,1);
m1p=m1(m1>0);
m1m=m1(m1<0);
load('../fortranp/discrete_m/result/rootm2.dat')
m2=rootm2(:,1);
m2p=m2(m2>0);
m2m=m2(m2<0);

%%
load('../fortranm/discrete_m/result/rootm.dat')
m3=rootm(:,1);
m3p=m3(m3>0);
m3m=m3(m3<0);
load('../fortranp/discrete_m/result/rootm.dat')
m4=rootm(:,1);
m4p=m4(m4>0);
m4m=m4(m4<0);
%%
f1=figure(1);
f1.Units='inches';
f1.Position=[0,0,9,12];
ax1=axes(f1,'Position',[0.1,0.03,0.8,0.45]);
plot(m1p(1:100),'o','MarkerSize',6)
hold on
plot(m2p(1:100),'.','MarkerSize',8)
ax1.XScale='log';
ax1.YScale='log';
ylabel('$m_o^{(n)}$','Interpreter','latex','FontSize',25)
%%%%%%
ax2=axes(f1,'Position',[0.1,0.53,0.8,0.45]);
plot(m3p(1:100),'o','MarkerSize',6)
hold on
plot(m4p(1:100),'.','MarkerSize',10)
ylabel('$m_o^{(n)}$','Interpreter','latex','FontSize',25)
f1.PaperPosition=[0,0,9,12];
f1.PaperSize=[9 12];
print(f1,'-dpdf','-r600','valuem')





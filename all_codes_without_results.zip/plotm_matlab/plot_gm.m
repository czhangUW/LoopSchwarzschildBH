clc;clear
% load('../fortranm/discrete_m/result/rootmg.dat')
% m1=rootm2(:,1);
% m1p=m1(m1>0);
% m1m=m1(m1<0);
load('../fortranp/discrete_m/result/rootmg.dat')
m2=rootmg(:,1);
m2p=m2(m2>0);
m2m=m2(m2<0);
%%
x=1:length(m2p);
x=sqrt(0.5*x.*(0.5*x+1));
x=x(:);
f1=figure(1);
f1.Units='inches';
f1.Position=[0,0,9,12];
ax1=axes(f1,'Position',[0.1,0.03,0.8,0.45]);
plot(x,m2p,'o','MarkerSize',6)

[xData, yData] = prepareCurveData( x, m2p );

% Set up fittype and options.
ft = fittype( 'power1' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';

opts.StartPoint = [0.544878056092938 1.01826898578563];

% Fit model to data.
[fitresult, gof] = fit( xData, yData, ft, opts );


